# plg_jem_demo
JEM Demo Plugin. This plugin will (re)create a set of data to demonstrate JEM. WARNING! Please DO NOT USE this plugin on production sites, It will delete all data every day!
